package cl.ceisufro.native_video_view

enum class PlayerState {
    NOT_INITIALIZED, PLAY_WHEN_READY, PREPARED, PLAYING, PAUSED
}