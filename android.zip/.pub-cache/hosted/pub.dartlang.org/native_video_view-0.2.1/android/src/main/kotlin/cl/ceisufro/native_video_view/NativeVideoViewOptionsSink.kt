package cl.ceisufro.native_video_view

interface NativeVideoViewOptionsSink {
    fun setUseExoPlayer(useExoPlayer: Boolean)
}