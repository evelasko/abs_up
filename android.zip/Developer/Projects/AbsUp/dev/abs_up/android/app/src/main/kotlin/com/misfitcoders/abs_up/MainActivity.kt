package com.misfitcoders.abs_up

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
